package br.com.inovatec.gestor.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import br.com.inovatec.gestor.dao.OsDAO;
import br.com.inovatec.gestor.modelo.ClienteModel;

@Controller
public class OSController {

	OsDAO dao = new OsDAO();

	@RequestMapping("/os")
	public String execute() {
		return "os";
	}

	@RequestMapping("incluir-os")
	public String incluirOS() {
		return "incluir-os";
	}

	@RequestMapping("/pesquisar-cliente-os-cnpj-cpf")
	public ModelAndView pesquisarClienteForCnpjCpf(@RequestParam(value = "cnpj_cpf") String cnpj_cpf) {
		List<ClienteModel> cliente = dao.pesquisarCNPJ_CPF(cnpj_cpf);
		ModelAndView mv = new ModelAndView("incluir-os");
		if (!cliente.isEmpty()) {
			mv.addObject("os", cliente);
		}else {
			mv.addObject("msg","Cliente com CNPJ/CPF informado n�o cadastrao!");
		}
		
		
		return mv;
	}
}
