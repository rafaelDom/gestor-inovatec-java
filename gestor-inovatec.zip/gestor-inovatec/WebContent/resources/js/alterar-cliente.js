function btnCancelar() {
	window.location.href = 'cliente';
}



