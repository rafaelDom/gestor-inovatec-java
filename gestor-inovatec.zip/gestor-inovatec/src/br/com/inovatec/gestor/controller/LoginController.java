package br.com.inovatec.gestor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	@RequestMapping("/")
	public String execute() {
		return "login";
	}
	
	@RequestMapping("/login")
	public String index() {
		return "login";
	}
}
